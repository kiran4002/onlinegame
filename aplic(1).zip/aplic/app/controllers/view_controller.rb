class ViewController < ApplicationController
  def google
  end

  def facebook
  end
end
