require 'test_helper'

class ViewHelperTest < ActionView::TestCase
end
