# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Aplic::Application.config.secret_token = '588fff274e91acd4442408d80bf0aaa5c35bc77f8f1953a85b5340188828de973608efae98c1f1880aa166698bbc002e110530f007e800a5e50f122595c178dc'
