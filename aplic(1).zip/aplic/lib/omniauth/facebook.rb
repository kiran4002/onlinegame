require 'omniauth/facebook/version'
require 'omniauth/strategies/facebook'
