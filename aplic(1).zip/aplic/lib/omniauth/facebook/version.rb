module OmniAuth
  module Facebook
    VERSION = "1.4.1"
  end
end
